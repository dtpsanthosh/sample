package interview;

public class TestStringMutable {

	public static void main(String[] args) {
		StringBuffer s = new StringBuffer("gsk");
		s.append("gummani");
		System.out.println(s);
	}

}

//op
//gskgummani