package interview;
import java.util.Arrays;
public class PrintArray {
	public static void main(String[] args) {
		// An array of String objects
		String[] array = new String[3];
		array[0] = "gsk";
		array[1] = "kumar";
		array[2] = "santhosh";
		System.out.println(Arrays.toString(array));
	}
}