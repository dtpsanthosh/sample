package interview;

public class Address {
	String hno;
	String street;
	String city;

	Address(String hno, String street, String city) {
		this.hno = hno;
		this.street = street;
		this.city = city;
	}

}
