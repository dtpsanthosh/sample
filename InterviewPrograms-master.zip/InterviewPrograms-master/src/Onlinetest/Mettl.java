package Onlinetest;

public class Mettl {

	public static void main(String[] args) {
		String s="This is a Line";
		String[] tokens=s.split("");
		System.out.println(tokens.length);
	}// o/p 14
}
