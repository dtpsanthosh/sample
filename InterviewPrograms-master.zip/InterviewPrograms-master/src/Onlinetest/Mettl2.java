package Onlinetest;

public class Mettl2 {
	public static void main(String[] args) {
		boolean t = true;
		System.out.println("Hello");
		if (t)
			return;
		System.out.println("Bye");
	}
}
