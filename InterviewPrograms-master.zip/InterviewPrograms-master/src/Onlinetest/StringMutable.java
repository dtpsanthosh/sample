package Onlinetest;

public class StringMutable {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("santhosh");
		sb.append("kumar");
		System.out.println(sb);
	}

}
