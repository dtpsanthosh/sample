package Onlinetest;
public class Test {
	public static void main(String[] args) {
		String s="santhosh";
		String s1=new String("santhosh");
		System.out.println(s.equals(s1));
		System.out.println(15/10%3);
	}

}
