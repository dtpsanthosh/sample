package Onlinetest;

public class Demo {
	public static void main(String[] args) {
		float 
		a=9;
		float b=2;
		System.out.println(a/b);
	}

}
