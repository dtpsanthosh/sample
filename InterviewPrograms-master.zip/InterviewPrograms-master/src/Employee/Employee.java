package Employee;
class Employee {
    public int emplId;
    public String empName;
    public double empSalary;
 
    public Employee(int emplId, String empName, double empSalary) {
        this.emplId = emplId;
        this.empName = empName;
        this.empSalary = empSalary;
    }
 
}