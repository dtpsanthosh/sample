package Astring;

class Test {

	public static void main(String[] args) {
		int a = 1234; 
		int b = -1234; 
		String str1 = Integer.toString(a); 
		String str2 = String.valueOf(b); 
		System.out.println("String str1 = " + str1); 
		System.out.println("String str2 = " + str2); 
	} 
	}

