package StreamAPI;

public class Student {

}
