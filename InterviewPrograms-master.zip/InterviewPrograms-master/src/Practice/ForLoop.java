package Practice;

public class ForLoop {

	public static void main(String[] args) {
		int n=6;
		for(int i=1;i<=10;i++)
		{
			System.out.println(n+"*"+i+"="+(n*i));
		}
	}

}
