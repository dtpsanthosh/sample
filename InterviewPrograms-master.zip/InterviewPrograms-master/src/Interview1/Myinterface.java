package Interview1;

public interface Myinterface {
	void m1();
	void m2();
}